export const UIFacade = {
    add: (domID, HTML) => {
        window.print()
    }
}